import paho.mqtt.client as mqtt
import time


def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))
    # Subscribe to a topic when connected
    client.subscribe("FunLand")


def on_message(client, userdata, msg):
    print("Received message: " + str(msg.payload.decode()))


def on_publish(client, userdata, mid):
    print("Message published")


